<?php
$id_telegram = "1545270267";
$id_botTele  = "6825440911:AAGBXe4wTcJjq8kTyr7e85aYA2EPtGz3Lw4";
?>
